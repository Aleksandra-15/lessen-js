//1. Створити таймер, який буде починати відлік з 1 години та зменшувати час кожну хвилину. При досягненні 30 хвилин, таймер повинен відправляти повідомлення екран про те, що залишилось менше половини часу.
const setTimer = document.querySelector("timer");
const startSec = document.querySelector("startBtn");
const stopSec = document.querySelector("stopBtn");

let hour = 3600;
let time = +startSec;
const counters = setInterval(() => {
  time--;
  getNamber.textContent = time;
  console.log("Time is our");
  if (time === 1800) {
    alert("Залишилось мало часу");
  }
}, hour * 1000);

//2.Створити таймер, який буде починати відлік з 30 секунд та зменшувати час кожну мілісекунду. При досягненні 10 секунд, таймер повинен відтворювати якусь анімацію, а при досягненні 0 секунд — виконувати певну дію, наприклад, робити кнопку почати знову активною.

const timout = document.querySelector("timout");
const goSecond = document.querySelector("goBtn");

let second = 30;
const timerid2 = setTimeout(() => {
  let time2 = +timout;
  const begin = setInterval(() => {
    console.log("Time is our");

    if (time2 < 10) {
      const box = document.getElementById("box");
      let pos = 0;

      function moveBox() {
        if (pos < 300) {
          pos++;
          box.style.left = pos + "px";
          box.style.top = pos + "px";
          requestAnimationFrame(moveBox);
        }
      }

      moveBox();
    }
  });
}, 1000);
clearInterval(timerid2);
